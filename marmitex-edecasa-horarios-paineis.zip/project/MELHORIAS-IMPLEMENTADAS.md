# Marmitex É De CASA — pacote de melhorias

Este pacote foi preparado a partir do ZIP enviado. Não contém `.env` nem credenciais privadas.

## Ajustes incluídos no código

- Horários padrão da loja definidos para almoço 10:30–15:00 e jantar 17:00–19:00.
- Verificação do horário da loja usa o fuso `America/Sao_Paulo`, para não depender do fuso do celular de quem acessa.
- Tela inicial com destaque visual, horários e estado de pedidos abertos/antecipados.
- A escolha entre entrega e retirada foi movida para a área de resumo do pedido, próxima ao pagamento. A escolha inicial é retirada, então a taxa de entrega não entra automaticamente no total.
- Mistura/proteína paga deixa de ser selecionada automaticamente. O cliente começa em “Sem mistura adicional”; qualquer opção paga precisa ser escolhida explicitamente.
- PIX começa como pagamento antecipado e não mostra a opção de pagar PIX na entrega.
- O painel de notificações existente foi preservado; o projeto já inclui o sino, o hook de notificações e infraestrutura de push. Push real depende de permissões do aparelho, configuração VAPID/servidor e implantação das funções Supabase.
- As proteções anteriores de PIN/duplicidade e disponibilidade do entregador foram preservadas.

## Limitações importantes / etapas que ainda exigem configuração

### Cartão de crédito/débito dentro do aplicativo
O código existente só descreve pagamento com maquininha na entrega. Não há um fluxo de cobrança online de cartão implementado no projeto atual. Não é seguro simular uma cobrança. Para ativar pagamento dentro do app, é necessário escolher e configurar um provedor (por exemplo, Stripe ou Mercado Pago), criar uma Edge Function/server-side para criar a cobrança, validar o webhook e atualizar o pedido apenas após confirmação do provedor. Não coloque chaves secretas em `VITE_*` nem no frontend.

### Cupons
A validação atual no cliente pode ser contornada por alguém que manipule o navegador. Para proteção real, o desconto precisa ser recalculado no servidor/banco na criação do pedido, com regras de validade, limite de uso e uso por cliente. O código do projeto foi preservado; esta proteção requer uma migração/função server-side compatível com o esquema real do banco e não deve ser aplicada no banco de produção sem revisão.

### Notificações push
Notificações dentro da tela e atualizações existentes foram preservadas. Push na barra de notificações depende de HTTPS, permissão explícita do usuário, chave VAPID pública/privada configurada com segurança e deploy da função `send-push`. iOS pode exigir que o app esteja instalado na Tela de Início e que o usuário conceda permissão.

## Como testar com segurança

1. Importe este ZIP como um projeto de teste ou aplique-o em uma branch separada no GitHub.
2. Configure apenas as variáveis públicas do Supabase necessárias ao frontend. Nunca adicione `STRIPE_SECRET_KEY` ao código frontend.
3. Confira a configuração de horários no painel administrativo e salve 10:30, 15:00, 17:00 e 19:00.
4. Teste um pedido sem escolher proteína paga: o preço não deve incluir adicional de proteína.
5. Teste retirada: a taxa de entrega deve ser zero. Escolha entrega e confirme que a taxa só entra depois dessa escolha.
6. Teste PIX: deve ser antecipado; a confirmação manual do pagamento continua necessária enquanto não houver integração automática.
7. Teste as notificações no dispositivo real e valide o build antes de publicar.
8. Não execute migrações no banco de produção sem revisar SQL, políticas RLS e backup.

## Validação

Este ambiente não conseguiu concluir `npm ci` dentro do tempo disponível, portanto o build e o typecheck não foram validados aqui. Execute `npm ci`, `npm run typecheck` e `npm run build` no ambiente de teste antes de publicar.

## Priorização automática por horário (22/10/2026)
- Os horários de almoço e jantar são lidos das configurações da loja, usando horário de Brasília (`America/Sao_Paulo`).
- Durante os horários configurados, o painel administrativo muda para a aba **Pedidos** automaticamente.
- Durante os mesmos períodos, o painel do entregador prioriza **Pedidos disponíveis** e mostra um aviso de horário ativo; a aba de rotas continua acessível.
- Fora dos horários, o usuário pode continuar usando as demais abas normalmente.
- Esta alteração é no front-end e ainda precisa ser validada com `npm run build` e testada com dados reais de homologação. Não altera o banco de dados.
