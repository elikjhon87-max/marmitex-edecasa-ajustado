# Compilar o Marmitex É De CASA sem Bolt

## Opção recomendada: Windows + Node.js + VS Code (sem tokens do Bolt)
1. Baixe e instale a versão LTS do Node.js: https://nodejs.org/
2. Instale o Visual Studio Code: https://code.visualstudio.com/
3. Extraia este ZIP para uma pasta no computador.
4. Abra a pasta `project` no VS Code.
5. Crie um arquivo `.env` com as variáveis necessárias copiando os nomes de `.env.example`. Use apenas chaves públicas apropriadas para o front-end (por exemplo, URL do Supabase e chave anon/publishable); nunca coloque chaves secretas de servidor no navegador.
6. No terminal do VS Code, execute:
   ```bash
   npm install
   npm run typecheck
   npm run build
   ```
7. Para visualizar localmente, execute `npm run dev` e abra o endereço local mostrado pelo terminal.

## Alternativas online
- GitHub Codespaces: ambiente de desenvolvimento no navegador conectado ao repositório; pode haver limites de uso e cobrança dependendo da conta.
- StackBlitz: útil para pré-visualizar projetos web no navegador; compatibilidade depende das dependências e do acesso às variáveis de ambiente.
- Replit: alternativa online para editar e executar projetos, também sujeita aos limites e planos atuais.

## Antes de publicar
- Faça commit/backup numa branch de teste.
- Configure as variáveis de ambiente no ambiente de teste.
- Não execute migrações no banco de produção sem revisão.
- Confirme login, pedidos, pagamentos, horários e fluxo do PIN de entrega.
